﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidPropagation
{
    class Outside : Site
    {
        private static SiteType[] outsideTypes = new SiteType[] { SiteType.Hobby, SiteType.Transport, SiteType.Eat };
        public Outside(double length = GlobalVariables.BUILDING_LENGTH,
                           double width = GlobalVariables.BUILDING_WIDTH,
                           double height = GlobalVariables.BUILDING_HEIGHT,
                           double ventilationWithOutside = GlobalVariables.BUILDING_VENTILATION_WITH_OUTSIDE,
                           double additionalControlMeasures = GlobalVariables.BUILDING_ADDITIONAL_CONTROL_MEASURES) :
                 base(outsideTypes, length, width, height, ventilationWithOutside, additionalControlMeasures)
        {

        }
    }
}
