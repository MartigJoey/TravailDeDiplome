﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidPropagation
{
    public enum SiteType
    {
        Home,
        Hobby,
        Store,
        Transport,
        Hospital,
        Eat,
        WorkPlace,
        School
    }
}
