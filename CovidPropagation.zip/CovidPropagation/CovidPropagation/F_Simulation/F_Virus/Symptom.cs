﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovidPropagation
{
    public interface Symptom
    {

    }
}
